var rIndex=1,
table = document.getElementById("table");
            
// check the empty input
function checkEmptyInput()
{
    var isEmpty = false,
        idno = document.getElementById("idno").value,
        name = document.getElementById("name").value,
        phone = document.getElementById("phone").value;

    if(idno === ""){
        alert("id number Connot Be Empty");
        isEmpty = true;
    }
    else if(name === ""){
        alert("Name Connot Be Empty");
        isEmpty = true;
    }
    else if(phone === ""){
        alert("phone Connot Be Empty");
        isEmpty = true;
    }
    return isEmpty;
}

// add Row
function addHtmlTableRow()
{
    // get the table by id
    // create a new row and cells
    // get value from input text
    // set the values into row cell's
    if(!checkEmptyInput()){
    var newRow = table.insertRow(table.length),
        cell1 = newRow.insertCell(0),
        cell2 = newRow.insertCell(1),
        cell3 = newRow.insertCell(2),
        idno = document.getElementById("idno").value,
        name = document.getElementById("name").value,
        phone = document.getElementById("phone").value;

    cell1.innerHTML = idno;
    cell2.innerHTML = name;
    cell3.innerHTML = phone;
    // call the function to set the event to the new row
   selectedRowToInput();
}
}
// display selected row data into input text
function selectedRowToInput()
{
    
    for(var i = 1; i < table.rows.length; i++)
    {
        table.rows[i].onclick = function()
        {
          // get the seected row index
          rIndex = this.rowIndex;
          document.getElementById("idno").value = this.cells[0].innerHTML;
          document.getElementById("name").value = this.cells[1].innerHTML;
          document.getElementById("phone").value = this.cells[2].innerHTML;
        };
    }
}
selectedRowToInput();

function editHtmlTbleSelectedRow()
{
    var idno = document.getElementById("idno").value,
        name = document.getElementById("name").value,
        phone = document.getElementById("phone").value;
   if(!checkEmptyInput()){
    table.rows[rIndex].cells[0].innerHTML = idno;
    table.rows[rIndex].cells[1].innerHTML = name;
    table.rows[rIndex].cells[2].innerHTML = phone;
  }
}

function removeSelectedRow()
{
    table.deleteRow(rIndex);
      // clear input text
    document.getElementById("idno");
    document.getElementById("name");
    document.getElementById("phone");
  
}